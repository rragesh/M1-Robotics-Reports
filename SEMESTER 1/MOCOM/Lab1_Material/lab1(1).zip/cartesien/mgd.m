% Calcul du Mod�le g�om�trique Direct
disp('entrer les valeurs articulaires');
q1 = input('q1 = ');
q2 = input('q2 = ');
q3 = input('q3 = ');
q4 = input('q4 = ');
q5 = input('q5 = ');
q6 = input('q6 = ');
q = [q1;q2;q3;q4;q5;q6];

% Calcul du MGD
% Extraction des coordonnees operationnelles (cosinus-directeur)
sx = 0;
nx = 0;
ax = 0;
Px = 0;
sy = 0;
ny = 0;
ay = 0;
Py = 0;
sz = 0;
nz = 0;
az = 0;
Pz = 0;

% Sauvegarde tampon des cosinus directeurs
s = [sx;sy;sz];
n = [nx;ny;nz];
a = [ax;ay;az];
P = [Px;Py;Pz];
% Application de la transformation dans le repere atelier
% Par rapport au rep�re atelier, il faut effectuer successivement
%	- une rotation rot(y0,90�)
%	- une rotation rot(z0,180�)
% L origine du rep�re atelier se trouve au point O0
% Soit une matrice de transformation homog�ne comme suit
%
%   [  0  0  1  0  ]		k= i
%   [  0 -1  0  0  ]		j=-j
%   [  1  0  0  0  ]		i= k
%   [  0  0  0  1  ]        Pz=Px;Py=-Py;Px=Pz;

% L'Orientation  A finir



%config robot
xf = [Px;Py;Pz;tetax;tetay;tetaz]
qsol = [q1;q2;q3;q4;q5;q6]

nbsolution = 1

