%Programmation du MGI
disp('Entrer les valeurs des variables operationnelles');
Px=input('Px = ');
Py=input('Py = ');
Pz=input('Pz = ');
tetax=input('tetax = ');
tetay=input('tetay = ');
tetaz=input('tetaz = ');
% Test d atteignabilite
%Calcul de q1,q2,q3
q1=;
q2=;
q3=;
%Calcul de q4,q5,q6
q4=;
q5=;
q6=;




