% Calcul du Mod�le g�om�trique Direct
disp('entrer les valeurs articulaires');
q1=input('q1 = ');
q2=input('q2 = ');
q3=input('q3 = ');
q4=input('q4 = ');
q5=input('q5 = ');
q6=input('q6 = ');
q=[q1;q2;q3;q4;q5;q6];

% Calcul du MGD
% Extraction des coordonnees operationnelles (cosinus-directeur)


%faire MGD


%faire MGI




visuart
pause
viseff
pause
