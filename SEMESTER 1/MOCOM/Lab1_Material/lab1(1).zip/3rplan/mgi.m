% Computing IGM of a 3R planar robot

disp('entrer les valeurs des variables operationnelles');
Px = input('Px = ');
Py = input('Py = ');
alpha = input('alpha = ');

% To be modified
% Complete the code to compute the two solutions for theta1 and theta2

q21=0;
q22=0;

q11=0;
q12=0;

% Computing theta3
q31=alpha-q21-q11;
q32=alpha-q22-q12;

% Putting solutions together in one matrix
qsol=[q11,q12;
      q21,q22;
      q31,q32];

if (q21 == 0 & q22 == 0 )
    nbsolution = 1
else
    nbsolution = 2
end;

