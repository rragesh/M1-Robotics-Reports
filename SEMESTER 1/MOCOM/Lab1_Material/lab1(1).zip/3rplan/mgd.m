% Compute DGM of a 3R planar robot
% input section
disp('entrer les valeurs articulaires');
q1=input('q1 = ');
q2=input('q2 = ');
q3=input('q3 = ');
q=[q1;q2;q3];

% To be modified
Px = 0; 
Py = 0; 
alpha = 0;


% Displaying the results
xf=[Px;Py;alpha]

qsol=[q1;
      q2;
      q3]

nbsolution=1

